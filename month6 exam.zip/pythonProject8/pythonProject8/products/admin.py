from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from products.models import Product, Category, Bestsellers, FeaturedItems


@admin.register(Category)
class CategoryAdmin(ImportExportModelAdmin):
    list_display = ('name',)
    list_display_links = ('name',)
    search_fields = ('name',)


@admin.register(Product)
class ProductAdmin(ImportExportModelAdmin):
    list_display = ['name', 'price', 'count', 'discription_20']
    list_display_links = ['name', 'price', 'count', 'discription_20']
    search_fields = ['name']

    def description_20(self, obj):
        return obj.description[:20]


@admin.register(Bestsellers)
class BestsellersAdmin(ImportExportModelAdmin):
    list_display = ['name']
    list_display_links = ['name']
    search_fields = ['name']


@admin.register(FeaturedItems)
class FeaturedItemsAdmin(ImportExportModelAdmin):
    list_display = ['name', 'discount']
    list_display_links = ['name', 'discount']
    search_fields = ['name']

